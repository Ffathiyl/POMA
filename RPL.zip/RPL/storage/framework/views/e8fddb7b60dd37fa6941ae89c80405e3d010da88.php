

<?php $__env->startSection('title','Tambah Admin'); ?>

<?php $__env->startSection('contents'); ?>

  <!-- Main -->
  <main id="main" class="main">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Form Tambah Admin</h5>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <div class="alert-title">
            <h4>Whoops!</h4>
          </div>
          There are some problems with your input.
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-success"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <!-- Vertical Form -->
        <form class="row g-3" action="<?php echo e(route('admins.store')); ?>" method="post">
          <?php echo csrf_field(); ?>

          <div class="col-12">
            <label for="Nama" class="form-label">Nama <span style="color: red;">*</span></label>
            <input type="text" class="form-control" id="Nama" name="Nama">
          </div>

          <div class="col-12">
            <label for="Jabatan" class="form-label">Jabatan <span style="color: red;">*</span></label>
            <input type="text" class="form-control" id="Jabatan" name="Jabatan">
          </div>

          <div class="col-12">
            <label for="Nohp" class="form-label">No Hp <span style="color: red;">*</span></label>
            <input type="text" class="form-control" id="Nohp" name="Nohp">
          </div>

          <div class="col-12">
            <label for="Kelamin" class="form-label">Kelamin <span style="color: red;">*</span></label><br>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="Kelamin" id="laki" value="Laki - Laki">
              <label class="form-check-label" for="laki">Laki-laki</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="Kelamin" id="perempuan" value="Perempuan">
              <label class="form-check-label" for="perempuan">Perempuan</label>
            </div>
          </div>

          <div class="col-12">
            <label for="Username" class="form-label">Username <span style="color: red;">*</span></label>
            <input type="text" class="form-control" id="Username" name="Username">
          </div>

          <div class="col-12">
            <label for="Password" class="form-label">Password <span style="color: red;">*</span></label>
            <div class="input-group">
              <input type="password" class="form-control" id="Password" name="Password">
              <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="col-12">
            <input type="hidden" class="form-control" id="Status" value="1" name="Status">
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
          </div>
        </form><!-- Vertical Form -->
      </div>
  </main>
  <!-- End - Main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <script>
    // Lihat password
    document.getElementById('togglePassword').addEventListener('click', function () {
      const passwordField = document.getElementById('Password');
      const fieldType = passwordField.getAttribute('type');

      if (fieldType === 'password') {
        passwordField.setAttribute('type', 'text');
      } else {
        passwordField.setAttribute('type', 'password');
      }
    });
  </script>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RPL\resources\views/admins/create.blade.php ENDPATH**/ ?>